#include "stdafx.h"
#include "Dj.h"


Dj::Dj()
{
}


Dj::~Dj()
{
}
