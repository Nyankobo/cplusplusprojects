// stdafx.cpp : source file that includes just the standard includes
// TanyaLandreth_MidTerm - Inventory Program.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#define _CRT_SECURE_NO_WARNINGS  //ADD THIS TO THE STDAFX.CPP to compile (before stdafx.h header preprocessor directive
#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
